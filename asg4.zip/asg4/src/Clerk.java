/**
 * Next, create two additional classes named Manager and Clerk 
 * that are derived from Employee.
Create an overridden method named addBonus that returns the salary 
of the employee after adding up the bonus. 
There is a default bonus of $200/month. 
Managers have a bonus of $300/month and clerks have a bonus of $100/month. 
Finally create a display method to print the details of the employee. 
Test your classes from a main method. 
You may assume the initial salary of an employee
and other necessary values.
 * @author Davian Canty
 *
 */
public class Clerk extends Employee {
	public Clerk() {
		super();
		this.setDesignation("Clerk");
	}
	public Clerk(String employeeID, String name, String department, double salary) {
		super(employeeID, name, department, "Clerk", salary);
	}
	public double addBonus() {
		this.setSalary(getSalary()+100);
		return getSalary();
	}
	public double getDeduction(int days) {
		return getSalary() / Employee.WORK_DAYS * (Employee.WORK_DAYS - days);
	}
}
