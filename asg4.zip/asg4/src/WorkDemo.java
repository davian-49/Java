import java.util.Scanner;

/**
 * Now, extend this to calculate the salary deductions 
 * based on the number of days an employee is on
leave. Consider 20 working days per month. 
Add an overridden method that calculates the deductions
of each employee based on their leave record. 
In your main method, create an array deduction (of type integer), 
filled with sample data of all types of Employees. 
Finally calculate the total deduction that
iterates through the array and returns the 
total amount of deductions of all the employees in a month.
 * @author Davian Canty
 *
 */
public class WorkDemo {

	public static void main(String[] args) {
		Employee[] payroll = { new Manager("E001", "Mark", "HR", 15000),
				new Manager("E012", "Peter", "R&D", 15000),
				new Clerk("EO56", "Samual", "Accounts", 10000),
				new Clerk("EO89", "Random", "Accounts", 9900)};
		for (Employee i : payroll)
		{
			System.out.println(i.display());
		}
		payroll[0].equals(payroll[2]);
		
		double[] deductions = new double[payroll.length];
		Scanner input = new Scanner(System.in);
		int days;
		double total = 0;
		for (int i= 0; i < payroll.length; i++)
		{
			System.out.println("Enter the number of days Employee " + payroll[i].getID() + 
					" is Present out of 20 :");
			days = input.nextInt();
			deductions[i] = payroll[i].getDeduction(days);
			payroll[i].setDaysPresent(days);
			total += (payroll[i].getDeduction(days));
			
		}
		input.close();
		
		for (int i= 0; i < payroll.length; i++)
		{
			System.out.println(payroll[i].toString() + deductions[i]);
		}
		
		System.out.println("\nTotal Deductions : " + total + ".");
		System.exit(0);

		
		
	}

}
