
/**
 * Create a class named Employee that can be used 
 * to calculate the salaries of different employees.
The Employee class should keep a track of the 
employee ID, name, department, salary,
and designation with appropriate accessor and mutator methods. 
Also create an equals() method that overrides Object�s equals() method, 
where employees can check if their designation is identical. 

Now, extend this to calculate the salary deductions based on 
the number of days an employee is on leave. Consider 20 working days per month. 
Add an overridden method that calculates the deductions
of each employee based on their leave record. 
In your main method, create an array deduction (of type integer), 
filled with sample data of all types of Employees. 
Finally calculate the total deduction that iterates through the array 
and returns the total amount of deductions of all the employees in a month.

 * @author Davian Canty
 *
 */

public class Employee {
	private String employeeID;
	private String name;
	private String department;
	private String designation;
	private double salary;
	final static int WORK_DAYS = 20; 
	private int daysPresent;
	
	// employee ID, name, department, salary,
	
	public Employee() { // no argument constructor 
		this.employeeID ="E000";
		this.name ="No Name";
		this.department= "No Department";
		this.salary = 0;
		this.designation = "No Designation";
		this.daysPresent = WORK_DAYS;
	}
	public Employee(String employeeID, String name, String department, 
			String designation, double salary)
	{
		this.employeeID =employeeID;
		this.name = name;
		this.department= department;
		this.designation = designation;
		this.salary = salary;
	}
	public Employee(Employee object)
	{
		this.employeeID = object.employeeID;
		this.name = object.name;
		this.department= object.department;
		this.designation = object.designation;
		this.salary = object.salary;
	}
	public void setID(String employeeID)
	{
		this.employeeID = employeeID;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public void setDepartment(String department)
	{
		this.department = department;
	}
	public void setDesignation(String designation)
	{
		this.designation = designation;
	}
	public void setSalary(double salary)
	{
		this.salary = salary;
	}
	public void setDaysPresent(int days)
	{
		if (days > 0)
		this.daysPresent = days;
	}
	public String getID()
	{
		return employeeID;
	}
	public String getName()
	{
		return name;
	}
	public String getDepartment()
	{
		return department;
	}
	public double getSalary()
	{
		return salary;
	}
	public double getDeduction(int days) {
		return salary / 20 * days;
	}
	public int getDaysPresent()
	{
		return daysPresent;
	}
	public double addBonus()
	{
		salary += 200;
		return salary;
	}
	public boolean equals(Employee other)
	{
		if(other==null)
		{
			System.out.println("null");
			return false;
		}
		else
		if (this.designation.equals(other.designation)) {
			System.out.println("Same Designation");
			return true;
		}
		
		else
			System.out.println("\n" + this.name + " and " + other.name + 
					" have different Designations.");
			return false;
	}
	public String display() {
		return "Employee ID : " + employeeID + 
				"\nEmployee name : " + name +
				"\nDepartment name : " + department +
				"\nSalary : "  + salary + 
				"\nDesignation : " + designation + "\nSalary after adding the bonus is : " + addBonus() + "\n";
	}
	public String toString() {
		return employeeID + 
				"\t" + daysPresent +
				"\t" + (WORK_DAYS - daysPresent) + "\t";
	}

}
