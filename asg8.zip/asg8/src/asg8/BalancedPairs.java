package asg8;

import java.util.Scanner;
import java.util.Stack;

/**
 * 
 * @author Davian Canty
 * Given an expression string, write a program to examine whether the pairs and the orders of parenthesis
{, }, (, ), [, ] are correct in expression.
For example, if the input: expression is entered by user is [()]{}{[()()]()},then the output
should print �Balanced�.
If the input: expression entered by user is [(]), then the output is �Not Balanced�
Hint: Traverse the input string and use stack to push if you encounter an opening parenthesis and
pop if you encounter a closing parenthesis of the same type.
Enter the parenthesis expression *
 */

public class BalancedPairs {
	
	public static boolean pairsBalanced(String expression)
	{
		Stack<Character> pairs = new Stack<Character>();

		// Traverse the input string and use stack to push if you encounter an opening parenthesis and
		// pop if you encounter a closing parenthesis of the same type.
		for (int i = 0; i < expression.length(); i++)
		{
			char in = expression.charAt(i);

			if (in == '{' || in == '(' || in == '[')
			{
				// Push the element in the stack
				pairs.push(in);
				continue;
			}
			if (pairs.isEmpty())
				return false;
			// If the input: expression entered by user is [(]), 
			// then the output is �Not Balanced�		
			char temp;
			switch (in) {
			case '}':
				temp = pairs.pop();
				if (temp == '(' || temp == '[')
					return false;
				break;

			case ')':
				temp = pairs.pop();
				if (temp == '{' || temp == '[')
					return false;
				break;

			case ']':
				temp = pairs.pop();
				if (temp == '(' || temp == '{')
					return false;
				break;
			}
		}

		// Check if Stack is empty again
		return (pairs.isEmpty());
	}

	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the parenthesis expression:");
		String input = scan.nextLine();
		scan.close();

		if (pairsBalanced(input))
			System.out.println("Balanced ");
		else
			System.out.println("Not Balanced ");
	}



}
