package file;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.util.StringTokenizer;
import java.awt.Desktop;  
/**
 * Write a program that edits a text file to display each complete sentence with a period at the end in a
separate line. . Create a temporary file, copy from the source file to a temporary file and perform the
required operation (write all sentences at a different line without a period). Copy the contents of the
temporary file back into the source file. Use a method (or methods) in the class File to remove the
temporary file.
You will also want to use the class File for other things in your program. The temporary file should
have a name that is different from all existing files so that the existing files are not affected (except for
the file being edited). Your program will ask the user for the name of the file to be edited. However,
it will not ask the user for the name of the temporary file but will instead generate the name within
the program. You can generate the name any way that is clear and efficient. One possible way to
generate the temporary file is to start with an unlikely name, such as "Temp1", and to append a digit,
such as '1', until a name is found that does not name an existing file.
 * @author Davian Canty
 *
 */

public class CopyEachLine {
	public static void main(String[] args) {
		//Ask the user to input file name containing sentences separated with a period
		Scanner keyboard=new Scanner(System.in);
		System.out.println("Enter source file name: ");
		String sourceFile=keyboard.nextLine();
		keyboard.close();
		
		//Create a temporary file, copy from the source file to a temporary file and re-write.
		
		// name different from all existing files so that the existing files are not affected
		
		File file=new File(sourceFile);
		if(file.exists())
			System.out.println("The file exists!");
			else
			System.out.println("The file doesn't exists!");
		
		
		FileInputStream input=null;
		Scanner scanFile=null;
		try {
			input=new FileInputStream(file);
			scanFile=new Scanner(input);
			System.out.println(file + " was opened");
		}catch(FileNotFoundException e) {
			System.out.println("The file "+sourceFile+" cannot open.");
			System.exit(0);
		}
		
		String targetFile = "temp.txt";
		
		int count = 1;
		while (new File(targetFile).exists())
			targetFile = count + targetFile;
			count++;
		
		StringTokenizer line = null;
		
		PrintWriter writeFile=null;
		try {
			writeFile=new PrintWriter(new FileOutputStream(targetFile));
		}catch(FileNotFoundException e) {
			System.out.println("The file targetFile cannot open.");
			System.exit(0);
		}
		line = new StringTokenizer(scanFile.nextLine(),".");
					
		while(scanFile.hasNext()) {
				while(line.hasMoreTokens()) 
				{
					writeFile.println(line.nextToken());
					;
				}
				
			line = new StringTokenizer(scanFile.nextLine(),".");

		}


		scanFile.close();
		writeFile.close();
		
		File edit = new File(targetFile);
		
		replaceFile(file, edit);
		
		// Copy the contents of the temporary file back into the source file
		
		
		/**
		Desktop desktop = Desktop.getDesktop();
		try {
			desktop.open(file);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		**/
		
		

	}
	
	static boolean replaceFile(File file, File edit) {
		file.delete();
		edit.renameTo(file);
		return true;
	}
}
