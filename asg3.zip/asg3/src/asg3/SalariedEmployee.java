package asg3;
/**
 * SalariedEmployee Class:
The SalariedEmployee class extends the Employee class and has instance variable salary. The class
will have the following three constructors:
1. No argument constructor
2. An argument constructor that receives name, hireDate and Salary.
3. An argument constructor that receives SalariedEmployee object.
Define the constructors, mutator and accessor methods, and suitably define toString and
equals methods. 
 * @author Davian Canty
 *
 */

public class SalariedEmployee extends Employee {
	
	private double salary;
	
	public SalariedEmployee() { // no argument constructor 
		super();
		salary = 0;
	}
	public SalariedEmployee(String name, Date hireDate, double salary)
	{
		super(name, hireDate);
		this.salary = salary;
	}
	public SalariedEmployee(SalariedEmployee object)
	{
		super(object);
		this.salary = object.salary;
	}
	public double getSalary()
	{
		return salary;
	}
	public double setSalary(double salary)
	{
		this.salary = salary;
		return salary;
	}
	public boolean equals(SalariedEmployee other)
	{
		if (this.getName().equals(other.getName())
				&& this.getHireDate().equals(other.getHireDate())
				&& this.salary==other.getSalary());
		return true;
	}
	public String toString() {
		return(this.getName() + " was hired on " + this.getHireDate() + " at Salary " + this.salary);
	}

}
