package asg3;
/**
 * Billing Class:
Give the definition of class Billing whose objects are records for a clinic. 
A Billing object will contain a Patient object, a Doctor object, 
and an amount due of type double.
 * @author Davian Canty
 *
 */

public class Billing {
	
	private Patient patient;
	private Doctor doctor;
	private double amountDue;

	public Billing() {
		patient = new Patient();
		doctor = new Doctor();
	}
	/**
	 * A Billing object will contain a Patient object, a Doctor object, 
	   and an amount due
	 * @param patient
	 * @param doctor
	 * @param amountDue
	 */
	public Billing(Patient patient, Doctor doctor, double amountDue)
	{
		this.patient = patient;
		this.doctor = doctor;
		this.amountDue = amountDue;
	}
	/**
	 * Copied Billing from other Billing
	 * @param other Billing
	 */
	public Billing(Billing other)
	{
		this.patient = other.patient;
		this.doctor = other.doctor;
		this.amountDue = other.amountDue;
	}
	public Patient getPatient(){
		return patient;
	}
	public Doctor getDoctor() {
		return doctor;
	}
	public double getAmountDue() {
		return amountDue;
	}
	public Patient setPatient(Patient other){
		this.patient = other;
		return other;
	}
	public Doctor setDoctor(Doctor other) {
		this.doctor = other;
		return other;
	}
	public double setAmountDue(double amountDue) {
		this.amountDue = amountDue;
		return amountDue;
	}
	public String toString() {
		return("Patient: " + this.patient.getName() + "\nDoctor: " + this.doctor.getName()
		+ "\nAmount Due: $" + amountDue + ".");
	}

}
