package asg3;
/**
 * 
 * @author Davian Canty
 *
 */
public class Demo {

	public static void main(String[] args) {
		
		Date date = new Date(12,31,1969);
		Doctor[] doctor = {
				new Doctor("Bob", date, 34000, "Pediatrist", 10.5),
				new Doctor("Susan", date, 450000, "Surgeon", 150.5),
				new Doctor("Lilly", date, 290000, "Kidney", 95.5)
				
		};
		for(int i=0; i<doctor.length; i++)
		{
			System.out.println(doctor[i]);
		}
		
		Patient[] patient = {
				new Patient("Fred", doctor[0]),
				new Patient("Sally", doctor[1]),
				new Patient("John", doctor[2])
				
		};
		System.out.println("\n*Patient's Information*");
		for(int i=0; i<patient.length; i++)
		{
			System.out.println(patient[i]);
		}
		System.out.println("\n*Billing's Information*");
		Billing[] bill = {
				new Billing(patient[0], doctor[0], 21),
				new Billing(patient[1], doctor[1], 150.5),
				new Billing(patient[2], doctor[2], 170)
				
		};
		for(int i=0; i<bill.length; i++)
		{
			System.out.println(bill[i]);
		}
		
		double total = 0;
		for (int i=0; i< bill.length; i++) {
			total += bill[i].getAmountDue();
		}
		
		System.out.println("\nThe total income from billing records is: $" + total);
	}

}
