package asg3;
/**
 * Employee Class:
The Employee class extends the Person class and has instance variable hireDate 
(since it will hold the hiring date of an employee so use Date class). 
This class will have following three constructors:
1. No argument constructor
2. An argument constructor that receives name and hireDate.
3. An argument constructor that receives Employee object.
Define the constructors, mutator and accessor methods, and suitably define toString and
equals methods
 * @author Davian Canty
 *
 */

public class Employee extends Person {
	
	private Date hireDate;
	
	public Employee() { // no argument constructor 
		super();
		hireDate = new Date();
	}
	public Employee(String name, Date hireDate)
	{
		super(name);
		this.hireDate = hireDate;
	}
	public Employee(Employee object)
	{
		super(object.getName());
		this.hireDate = object.hireDate;
	}
	public Date setHireDate(Date hireDate)
	{
		this.hireDate = hireDate;
		return hireDate;
	}
	public Date getHireDate()
	{
		return hireDate;
	}
	public boolean equals(Employee other)
	{
		if (this.getName().equals(other.getName())
				&& this.getHireDate().equals(other.getHireDate()) );
		return true;
	}
	public String toString() {
		return(this.getName() + " was hired on " + hireDate.toString());
	}

}
