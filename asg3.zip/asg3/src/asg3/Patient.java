package asg3;
/**
 * Patient Class:
Give the definition of class Patient whose objects are records for a clinic. 
Patient will be derived from the class Person. 
A Patient record has the patient�s name (inherited from the class Person) 
and primary physician of type Doctor. Be sure your class has a reasonable complement 
of constructors, accessor and mutator methods, and suitably defined 
equals and toString methods.
 * @author Davian Canty
 *
 */

public class Patient extends Person {
	private Doctor primary; // primary physician of type Doctor

	public Patient() {
		super();
		this.setPrimary(new Doctor());
	}
	
	/**
	 * A Patient record has the patient�s name and primary physician of type Doctor
	 * @param name patient's name
	 * @param primary physician of type Doctor
	 */
	public Patient(String name, Doctor primary) {
		super(name);
		this.primary = primary;
	}
	/**
	 * Patient copied from other Patient
	 * @param other Patient
	 */
	public Patient(Patient other) {
		super(other);
		this.primary = other.primary;
	}
	/**
	 * Gets primary physician of type Doctor
	 * @return primary physician of type Doctor
	 */
	public Doctor getPrimary() {
		return primary;
	}
	/**
	 * Sets primary physician of type Doctor
	 * @param primary Doctor
	 * @return Doctor set
	 */
	public Doctor setPrimary(Doctor primary) {
		this.primary = primary;
		return primary;
	}
	public boolean equals(Patient other)
	{
		if (this.getName().equals(other.getName())
				&& this.primary.equals(other.getPrimary()) );
		return true;
	}
	public String toString() {
		return("The name is: " + this.getName() + ", Primary Doctor is: " + this.primary.getName());
	}

}
