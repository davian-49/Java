package asg3;
/**
 * @author Davian Canty
 *
 */
public class Person{

	private String name;
	public Person() {
		name = "No Name";
	}
	public Person(String name){
		this.name = name;
	}
	public Person(Person object){
		this.name = object.name;
	}
	public String getName() {
		return name;
	}
	public String setName(String name){
		this.name = name;
		return name;
	}
	public String toString()
	{
		return name;
	}
	public boolean equals(Person other)
	{
		if (this.name.equals(other.name))
			return true;
		else
			return false;

	}
}
