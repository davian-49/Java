package asg3;

/**
 * Doctor Class:
Class named Doctor whose objects are records for a clinic�s doctors. 
This class will be a derived class of the class SalariedEmployee. 
A Doctor record has the doctor�s specialty and office visit fee. 
 * @author Davian Canty
 *
 */
public class Doctor extends SalariedEmployee {
	
	private String specialty; // such as "General Practitioner"
	private double officeFee;
	/**
	 * A Doctor record has the doctor�s specialty and office visit fee
	 */
	public Doctor() {
		super();
		specialty = "No Practice";
		officeFee = 0;
	}
	/**
	 * Represents Doctor
	 * @param name known as
	 * @param hireDate date hired
	 * @param salary dollars amount
	 * @param specialty such as "Pediatrician"
	 * @param officeFee office visit fee
	 */
	public Doctor(String name, Date hireDate, double salary, 
			String specialty, double officeFee)
	{
		super(name, hireDate, salary);
		this.specialty = specialty;
		this.officeFee = officeFee;
	}
	/**
	 * Doctor copied from other Doctor
	 * @param other Doctor
	 */
	public Doctor(Doctor other)
	{
		super(other);
		this.specialty = other.specialty;
		this.officeFee = other.officeFee;
	}
	/**
	 * Such as "Pediatrician", "Obstetrician", "General Practitioner", and so forth
	 * @return specialty
	 */
	public String getSpecialty()
	{
		return specialty;
	}
	/**
	 * Office visit fee
	 * @return office visit fee
	 */
	public double getOfficeFee()
	{
		return officeFee;
	}
	public boolean equals(Doctor other)
	{
		if (this.getName().equals(other.getName())
				&& this.getHireDate().equals(other.getHireDate())
				&& this.getSalary()==other.getSalary()
				&& this.specialty.equals(other.specialty)
				&& this.officeFee==other.officeFee);
		return true;
	}
	public String toString() {
		return("The Doctor " + this.getName() + " was hired on " + this.getHireDate() + " at Salary " + this.getSalary() 
		+ ".\nThe specialty is " + specialty + " and visit fee is $" + officeFee + ".");
	}

}
