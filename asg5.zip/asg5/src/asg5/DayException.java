package asg5;
/**
 *  if the user enters anything other than a valid day number (integers from 1 to either
28, 29, 30, or 31, depending on the month and year), then your program will throw and catch a
DayException and ask the user to reenter the day
 * @author Davian Canty
 *
 */
public class DayException extends Exception {
	
	public DayException() {
		super();
	}
	public DayException(String message)
	{
		super(message);
	}

}
