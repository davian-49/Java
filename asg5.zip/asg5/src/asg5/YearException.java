package asg5;
/**
 * If the user enters a year that is not in the range
1000 to 3000 (inclusive), then your program will throw and catch a YearException and ask the
user to reenter the year. (There is nothing very special about the numbers 1000 and 3000 other than
giving a good range of likely dates.)
 * @author Davian Canty
 *
 */
public class YearException extends Exception {
	public YearException() {
		super();
	}
	public YearException(String message)
	{
		super(message);
	}

}
