package asg5;
/**
 * . If the user enters anything other than a legal month number (integers from
1 to 12), your program will throw and catch a MonthException and ask the user to reenter the
month
 * @author Davian Canty
 *
 */
public class MonthException extends Exception {
	
	public MonthException() {
		super();
	}
	public MonthException(String message)
	{
		super(message);
	}
}
