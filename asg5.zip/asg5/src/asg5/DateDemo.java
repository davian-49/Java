package asg5;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.StringTokenizer;

/**
 * In the main program, you will ask user to enter the date in MM/DD/YYYY format and then print
the formatted date if user enters the valid date.
Hint: Use StringTokenizer class to parse the date input by user. 
 * @author Davian Canty
 *
 */
public class DateDemo {

	public static void main(String[] args) {
		Date validDate = new Date();
		StringTokenizer date;
		
		
		Scanner input = new Scanner(System.in);
		boolean done = false;
		while(!done) {
			try{
				System.out.println("Enter date to parse (MM/DD/YYYY format: )");
				date = new StringTokenizer(input.nextLine(),"/");
				int month = Integer.parseInt(date.nextToken());
				if(!validDate.monthOK(month))
					throw new MonthException("Invalid month. Reenter a valid month:");
				else
					validDate.setMonth(month);
				int day = Integer.parseInt(date.nextToken());
				if(!validDate.dayOK(day, month))
					throw new DayException("Invalid day. Reenter a valid day: ");
				else
					validDate.setDay(day);
				int year = Integer.parseInt(date.nextToken());
				if(!validDate.yearOK(year))
					throw new YearException("Invalid year. Reenter a valid year:");
				else
					validDate.setYear(year);
				
				System.out.println("Parsed date: " + validDate);
				done = true;
			}
			catch(MonthException e) {
				System.out.println(e.getMessage());
			}
			catch(DayException e) {
				
				System.out.println(e.getMessage());
			}
			catch(YearException e) {
				input.nextLine();
				System.out.println(e.getMessage());
			}
			catch(Exception e) {
				System.out.println("Some error occured");
			}
			
		}
		
		
	}

}
