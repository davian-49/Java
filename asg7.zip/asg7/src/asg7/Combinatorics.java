package asg7;

import java.util.Scanner;

/**
 * @author Davian Canty
 * 			2999151	
 * Discover a recursive version of the formula for C(n,r) and write a recursive method that computes
the value of the formula. Place the method in a class that has a main that test the method

 */
public class Combinatorics {
	/**
	 * recursive version of the formula for C(n,r)
	 * @param n must be greater than r
	 * @param r
	 * @return combination on n "choose" r
	 */
	public static int combine(int n, int r) {
		// base case (n must be > r) n=1, r=0
		if (n == 1)
			return 1;
		else 
			if ( n == r+1 )
				return n;
			else
				if (r == 0)
					return 1;
		else
			return combine(n - 1, r - 1)
		            + combine(n - 1, r);
				
	}

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter value for n:");
		int n = scan.nextInt();
		System.out.println("Enter value for r:");
		int r = scan.nextInt();
		scan.close();
		System.out.println("There are " + combine(n,r) + " possible combinations.");

	}

}
