package asg2;

import java.util.Scanner;

public class SeatDemo {

	public static void main(String[] args) {
		AirplaneSeats air = new AirplaneSeats();
		System.out.println("You will be selecting seats for this airplane.");
		System.out.println(air);
		System.out.println("You will input the seat selection using the row number "
				+ "and then the seat letter (ex - 3B)");
		Scanner input = new Scanner(System.in);
		while (!air.isFull)
		{
			
			System.out.println("Please enter the seat number or Q to quit");
			if(air.seatSelect(input.next()))
			{
				System.out.println(air);
			}
			air.check();
		}
		input.close();
	}

}
