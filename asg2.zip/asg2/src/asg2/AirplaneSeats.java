package asg2;

/**
 * COP 3337 - Assignment II
 * Multidimensional Arrays
 * Program to assign passengers seats in an airplane.
 * Assume a small airplane with seat numbers as follows:
		1 A B C D
		2 A B C D
		3 A B C D
		4 A B C D
		5 A B C D
		6 A B C D
		7 A B C D
 * @author dcant019
 *
 */
public class AirplaneSeats {
	int[][] seats; // array to store seats in rows and columns
	boolean isFull; // checks whether there is more space on plane
	/**
	 * Creates empty Airplane
	 */
	public AirplaneSeats() {
		isFull = false; // plane is empty
		seats = new int[7][4]; // 7 rows, 4 seats per row	
		for (int row = 0; row < seats.length; row++)
		{
			for (int col = 0; col < seats[row].length; col++ ) {
				seats[row][col] = col;
			}
		}
	}
	/**
	 * Copy of AirplaceSeats
	 * @param airPlane
	 */
	public AirplaneSeats(AirplaneSeats airPlane) {
		isFull = airPlane.isFull; 
		seats = airPlane.seats; // 7 rows, 4 seats per row	
	}

	
	/**
	 * Seat selection using the row number and then the seat letter
	 * @param row row number
	 * @param col seat letter
	 */
	public void setSeat(int row, int col) {
		
		if( seats[row][col] == 4)
		{
			System.out.println("Seat already assigned");
			return;
		}
		else
			seats[row][col] = 4;
		
	}
	
	/**
	 * Helper method converts seat input, ex - 3B, into row 3 and col B
	 * @param seat
	 */
	public boolean seatSelect(String seat)
	{
		if (seat.equalsIgnoreCase("Q"))
		{
			isFull = true;
			System.out.println("You have quit seat selection");
			return true;
		}
		
		int row = Integer.valueOf(seat.substring(0, 1)); // row 1-7
		char col = seat.charAt(1); // column A-D
		if (row > 0)
		{
			if (row <= 7)
			{
				row--;
				switch(col) {
				case 'A' | 'a': setSeat(row, 0); return true;
				case 'B' | 'b': setSeat(row, 1); return true;
				case 'C' | 'c': setSeat(row, 2); return true;
				case 'D' | 'd': setSeat(row, 3); return true;
				default: System.out.println("Error, incorrect column format"); 
				return false;
				}
			}
		}

			System.out.println("Error, incorrect seat format");
			return false;
	}
	
	/**
	 * Converts seat to a letter (helper method)
	 * @param seat
	 * @return seat as letter A, B, C, or D
	 */
	public String seat(int seat) {
		switch(seat) {
		case 0: return "A";
		case 1: return "B";
		case 2: return "C";
		case 3: return "D";
		default: return "X";
		}
	}
	
	/**
	 * Check plane actively to see if there are seats available (helper method)
	 * @return true if there are no more seats available, false if not
	 */
	public boolean check() {
		int counter = 0; // keeps seat count for seats
		for (int i = 0; i < seats.length; i++) {
			for (int j = 0; j < seats[i].length; j++) {
				if(seats[i][j]==4) {
					counter++; // if seat if full
				}
			}
		}
		if ( counter == (seats.length*seats[0].length)) {
			isFull = true;
			System.out.println("There are no more seats available");
			return true;
		}
		return false;
	}
	
	/**
	 * Outputs 7 rows of seats in the format
	 * 1 A B C D
	 */
	public String toString() {
		String airplane = "";
		for(int i = 0; i < seats.length; i++) // rows 1-7
		{
			airplane += (i+1 + " ");
			for (int j = 0; j < seats[i].length; j++) {
				airplane += (seat(seats[i][j]) + " "); // columns A-D
			}
			
			airplane += "\n";
			
		}
		return airplane;
	}

}
